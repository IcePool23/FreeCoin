Sample configuration files for:
```
SystemD: freed.service
Upstart: freed.conf
OpenRC:  freed.openrc
         freed.openrcconf
CentOS:  freed.init
OS X:    org.free.freed.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
