Building Free
================

See doc/build-*.md for instructions on building the various
elements of the Free Core reference implementation of Free.
