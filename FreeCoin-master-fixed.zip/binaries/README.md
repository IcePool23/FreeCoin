Releases have been moved to:

https://github.com/FreeProject/Freecoin/releases/latest
